package com.example.soul.grupo1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

public class Autocomplete extends AppCompatActivity {

    private String[] os = { "Dennis Mayor", "Majito Brava Macias", "Jonathan Larrea",
            "Edwin Robalino", "Anali Comelibros Moreano", "Ivone Burgos", "Kevin Kevin", "Nathali", "Diana Coello", "Cindy Rodriguez"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autocomplete);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, os);



        AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView1);
        textView.setThreshold(3);
        textView.setAdapter(adapter);
    }
}
