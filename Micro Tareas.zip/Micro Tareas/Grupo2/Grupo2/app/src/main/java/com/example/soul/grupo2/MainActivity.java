package com.example.soul.grupo2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void webview (View v) {

        // get values and then displayed in a toast
        Intent intent = new Intent(this,WebView.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        String message = "Dummy";
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);


    }

    public void listview (View v){

        // get values and then displayed in a toast
        Intent intent = new Intent(this,WebView.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        String message = "Dummy";
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);

    }

}
