package com.example.soul.grupo2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

public class WebViewApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);



    }

    public void browse (View v) {

        WebView webView = (WebView)this.findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient(){});
        EditText website = (EditText)(this.findViewById(R.id.editText));
        webView.loadUrl(website.getText().toString());


    }
}
